/* Mac 控制台 Service Worker —— 不再缓存页面，保证每次刷新都拿到最新（本地 LAN 工具，避免旧缓存导致"改了不生效"） */
const CACHE = "mac-console-v2";

self.addEventListener("install", e => {
  // 不预缓存 HTML；立即激活新 SW
  self.skipWaiting();
});

self.addEventListener("activate", e => {
  // 清掉所有旧缓存（含 mac-console-v1 里缓存的旧 index.html），并接管所有页面
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;            // 非 GET 走默认（网络）
  const url = new URL(req.url);
  if (url.pathname.startsWith("/api/")) {      // API 始终走网络，保证实时控制
    e.respondWith(fetch(req));
    return;
  }
  // 页面导航（index.html）一律走网络，绝不读旧缓存；
  // 其余静态资源网络优先、失败再回退缓存（离线时图标/清单仍可用）
  if (req.mode === "navigate") {
    e.respondWith(fetch(req).catch(() => caches.match(req)));
    return;
  }
  e.respondWith(
    fetch(req).then(resp => {
      const copy = resp.clone();
      caches.open(CACHE).then(c => c.put(req, copy));
      return resp;
    }).catch(() => caches.match(req))
  );
});
